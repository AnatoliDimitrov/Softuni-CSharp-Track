﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        private static IMapper mapper;

        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();
            //ResetDatabase(context);

            var importUsersXML = File.ReadAllText("../../../Datasets/users.xml");
            Console.WriteLine(ImportUsers(context, importUsersXML));
        }

        private static void ResetDatabase(ProductShopContext ctx)
        {
            ctx.Database.EnsureDeleted();
            ctx.Database.EnsureCreated();

            Console.WriteLine("Reset Database Successful");
        }

        private static void CreateMapper()
        {
            MapperConfiguration configuration = new MapperConfiguration(c =>
            {
                c.AddProfile(new ProductShopProfile());
            });

            mapper = new Mapper(configuration);
        }

        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            CreateMapper();

            XmlRootAttribute root = new XmlRootAttribute("Users");
            XmlSerializer serializer = new XmlSerializer(typeof(ImportUserDto[]) ,root);

            using StringReader reader = new StringReader(inputJson);

            ImportUserDto[] dtos = (ImportUserDto[])serializer.Deserialize(reader);

            context.Users
                .AddRange(mapper.Map<IEnumerable<User>>(dtos));

            context.SaveChanges();

            return $"Successfully imported {dtos.Length}";
        }
    }
}