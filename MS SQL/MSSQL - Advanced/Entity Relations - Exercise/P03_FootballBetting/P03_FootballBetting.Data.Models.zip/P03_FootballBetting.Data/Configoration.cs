﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public static class Configoration
    {
        public const string connectionString = "Server=.;Database=Bet;Integrated Security=True;";
    }
}
