﻿namespace MusicHub.Data.Models
{
    public enum Genre
    {
        Blues = 1, 
        Rap = 2, 
        PopMusic = 3, 
        Rock = 4, 
        Jazz = 5
    }
}
