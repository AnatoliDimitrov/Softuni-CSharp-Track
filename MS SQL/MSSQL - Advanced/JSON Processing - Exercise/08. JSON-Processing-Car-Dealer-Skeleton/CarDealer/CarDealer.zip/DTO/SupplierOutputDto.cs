﻿namespace CarDealer.DTO
{
    public class SupplierOutputDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int PartsCount { get; set; }
    }
}
