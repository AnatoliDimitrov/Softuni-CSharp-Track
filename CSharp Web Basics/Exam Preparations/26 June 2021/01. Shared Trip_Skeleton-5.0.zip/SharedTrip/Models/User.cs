﻿namespace SharedTrip.Models
{
    public class User
    {
        
    }
}
