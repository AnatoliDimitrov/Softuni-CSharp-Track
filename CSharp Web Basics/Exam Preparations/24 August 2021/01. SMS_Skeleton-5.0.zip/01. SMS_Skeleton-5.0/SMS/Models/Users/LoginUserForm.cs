﻿namespace SMS.Models.Users
{
    public class LoginUserForm
    {
        public string Username { get; init; }

        public string Password { get; init; }
    }
}
