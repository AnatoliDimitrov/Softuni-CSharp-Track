﻿namespace FootballManager.ViewModels.Players
{
    using System;

    public class AllPlayerViewModel
    {
        public string Id { get; init; } = Guid.NewGuid().ToString();

        public string FullName { get; init; }

        public string ImageUrl { get; init; }

        public string Position { get; init; }

        public byte Speed { get; init; }

        public byte Endurance { get; init; }

        public string Description { get; init; }
    }
}
