﻿namespace FootballManager.Common
{
    internal class Constants
    {
        public const int LENGTH_200 = 200;
        public const int LENGTH_100 = 100;
        public const int LENGTH_80 = 80;
        public const int LENGTH_60 = 60;
        public const int LENGTH_20 = 20;
        public const int LENGTH_10 = 10;
        public const int LENGTH_9 = 9;
        public const int LENGTH_8 = 8;
        public const int LENGTH_7 = 7;
        public const int LENGTH_6 = 6;
        public const int LENGTH_5 = 5;
        public const int LENGTH_4 = 4;
        public const int LENGTH_3 = 3;
        public const int LENGTH_2 = 2;
        public const int LENGTH_1 = 1;

        public const string EMAIL_REGEX_PATTERN = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";

        public const string DATE_FORMAT = "dd.MM.yyyy HH:mm";

        public const string MAJOR_ERROR = "Something went wrong. Please try again Later";
    }
}
