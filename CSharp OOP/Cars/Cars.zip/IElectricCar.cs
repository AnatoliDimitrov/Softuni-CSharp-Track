﻿namespace Cars
{
    interface IElectricCar : ICar
    {
        public int Battery { get;}
    }
}
