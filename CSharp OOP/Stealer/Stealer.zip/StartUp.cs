﻿namespace Spy
{
    [Author("Venci")]
    public class StartUp
    {
        [Author("Gosho")]
        public static void Main()
        {
        }
    }
}
