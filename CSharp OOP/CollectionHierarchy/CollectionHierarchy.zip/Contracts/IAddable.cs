﻿namespace CollectionHierarchy.Contracts
{
    public interface IAddable
    {
        public int Add(string element);
    }
}
