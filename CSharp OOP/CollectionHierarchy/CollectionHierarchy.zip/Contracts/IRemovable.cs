﻿namespace CollectionHierarchy.Contracts
{
    public interface IRemovable : IAddable
    {
        public string Remove();
    }
}
