﻿using System;

namespace Spyg
{
    [Author("Venci")]
    public class StartUp
    {
        [Author("Gosho")]
        public static void Main()
        {
            Tracker tracker = new Tracker();
            tracker.PrintMethodsByAuthor();
        }
    }
}
