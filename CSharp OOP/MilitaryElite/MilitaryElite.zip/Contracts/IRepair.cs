﻿namespace MilitaryElite.Contracts
{
    public interface IRepair
    {
        public string Name { get; }

        public int HoursWorked { get; }
    }
}
