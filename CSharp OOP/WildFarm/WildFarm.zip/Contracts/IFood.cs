﻿namespace WildFarm.Contracts
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
