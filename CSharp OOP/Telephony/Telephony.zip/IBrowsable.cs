﻿namespace Telephony
{
    public interface IBrowsable
    {
        void Browse(string site);
    }
}
