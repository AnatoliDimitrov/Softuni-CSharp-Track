﻿namespace BirthdayCelebrations
{
    public interface IRobot
    {
        public string Model { get; }

        public string Id { get; }
    }
}
